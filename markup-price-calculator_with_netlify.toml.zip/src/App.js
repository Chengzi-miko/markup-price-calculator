import React, { useState } from 'react';
import './App.css';

function App() {
  const [cost, setCost] = useState('');
  const [margin, setMargin] = useState('');
  const [price, setPrice] = useState(null);
  const [batchInput, setBatchInput] = useState('');
  const [batchResults, setBatchResults] = useState([]);

  const calculatePrice = (cost, margin) => {
    return (parseFloat(cost) * (1 + parseFloat(margin) / 100)).toFixed(3);
  };

  const handleSingleCalculation = () => {
    if (cost && margin) {
      setPrice(calculatePrice(cost, margin));
    }
  };

  const handleBatchCalculation = () => {
    const lines = batchInput.split('\n');
    const results = lines.map(line => {
      const [c, m] = line.split(',').map(item => item.trim());
      if (c && m) {
        return { cost: c, margin: m, price: calculatePrice(c, m) };
      }
      return null;
    }).filter(item => item !== null);
    setBatchResults(results);
  };

  return (
    <div className="App">
      <header className="App-header">
        <h2>毛利报价计算器</h2>
        <div>
          <h3>单个计算</h3>
          <input type="number" placeholder="成本" value={cost} onChange={e => setCost(e.target.value)} />
          <input type="number" placeholder="毛利率 (%)" value={margin} onChange={e => setMargin(e.target.value)} />
          <button onClick={handleSingleCalculation}>计算</button>
          {price && <p>报价：{price}</p>}
        </div>
        <div>
          <h3>批量计算</h3>
          <textarea placeholder="每行输入：成本,毛利率 (%)" value={batchInput} onChange={e => setBatchInput(e.target.value)} />
          <button onClick={handleBatchCalculation}>批量计算</button>
          {batchResults.length > 0 && (
            <table>
              <thead>
                <tr><th>成本</th><th>毛利率 (%)</th><th>报价</th></tr>
              </thead>
              <tbody>
                {batchResults.map((r, i) => (
                  <tr key={i}><td>{r.cost}</td><td>{r.margin}</td><td>{r.price}</td></tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </header>
    </div>
  );
}

export default App;